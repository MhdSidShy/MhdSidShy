import React from "react";

const About = () => (<div><h1>About</h1></div>);

export default About;